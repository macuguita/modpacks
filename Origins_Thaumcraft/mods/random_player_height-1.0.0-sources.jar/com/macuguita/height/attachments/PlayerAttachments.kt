@file:Suppress("UnstableApiUsage")

package com.macuguita.height.attachments

import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget

data class PlayerAttachments(private val target: AttachmentTarget) {

    private fun currentHeight(target: AttachmentTarget) =
        target.getAttachedOrElse(
            Attachments.HEIGHT_MODIFIER,
            HeightModifier.DEFAULT
        )

    private fun currentJoined(target: AttachmentTarget) =
        target.getAttachedOrElse(
            Attachments.HAS_JOINED,
            HasJoined.DEFAULT
        )

    var heightModifier: Double
        get() = currentHeight(target).heightModifier
        set(value) {
            target.setAttached(
                Attachments.HEIGHT_MODIFIER,
                currentHeight(target).copy(heightModifier = value)
            )
        }

    fun markJoined() =
        target.setAttached(
            Attachments.HAS_JOINED,
            currentJoined(target).markJoined()
        )

    val hasJoined: Boolean
        get() = currentJoined(target).hasJoined
}
