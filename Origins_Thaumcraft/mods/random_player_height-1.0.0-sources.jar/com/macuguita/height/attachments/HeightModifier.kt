package com.macuguita.height.attachments

import com.mojang.serialization.Codec

data class HeightModifier(val heightModifier: Double) {

    companion object {
        val DEFAULT = HeightModifier(1.0)

        val CODEC: Codec<HeightModifier> = Codec.DOUBLE.xmap(::HeightModifier, HeightModifier::heightModifier)
    }
}
