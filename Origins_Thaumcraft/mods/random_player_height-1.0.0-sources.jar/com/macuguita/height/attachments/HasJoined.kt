package com.macuguita.height.attachments

import com.mojang.serialization.Codec

data class HasJoined(val hasJoined: Boolean) {

    companion object {
        val DEFAULT = HasJoined(false)

        val CODEC: Codec<HasJoined> = Codec.BOOL.xmap(::HasJoined, HasJoined::hasJoined)
    }

    fun markJoined(): HasJoined =
        copy(hasJoined = true)
}
