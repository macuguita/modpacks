package com.macuguita.height.attachments

import com.macuguita.height.RandomPlayerHeight
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry
import net.fabricmc.fabric.api.attachment.v1.AttachmentType

object Attachments {

    val HAS_JOINED: AttachmentType<HasJoined> =
        AttachmentRegistry.create(
            RandomPlayerHeight.id("has_joined")
        ) { builder ->
            builder
                .initializer { HasJoined.DEFAULT }
                .persistent(HasJoined.CODEC)
                .copyOnDeath()
        }

    val HEIGHT_MODIFIER: AttachmentType<HeightModifier> =
        AttachmentRegistry.create(
            RandomPlayerHeight.id("height_modifier")
        ) { builder ->
            builder
                .initializer { HeightModifier.DEFAULT }
                .persistent(HeightModifier.CODEC)
                .copyOnDeath()
        }
}