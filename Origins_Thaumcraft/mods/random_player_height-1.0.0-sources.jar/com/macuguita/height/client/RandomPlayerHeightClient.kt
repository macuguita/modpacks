package com.macuguita.height.client

import net.fabricmc.api.ClientModInitializer

object RandomPlayerHeightClient : ClientModInitializer {
	override fun onInitializeClient() {
	}
}