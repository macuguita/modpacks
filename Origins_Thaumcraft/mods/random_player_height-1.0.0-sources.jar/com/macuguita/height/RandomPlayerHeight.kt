package com.macuguita.height

import com.google.common.reflect.Reflection
import com.macuguita.height.attachments.Attachments
import com.macuguita.height.attachments.PlayerAttachments
import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents
import net.minecraft.commands.Commands
import net.minecraft.commands.arguments.EntityArgument
import net.minecraft.network.chat.Component
import net.minecraft.resources.Identifier
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.entity.ai.attributes.AttributeModifier
import net.minecraft.world.entity.ai.attributes.Attributes
import org.slf4j.LoggerFactory
import kotlin.random.Random

object RandomPlayerHeight : ModInitializer {

	const val MOD_ID: String = "random_player_height"
	val SIZE_MODIFIER = id("size_modifier")

	private val LOGGER = LoggerFactory.getLogger(MOD_ID)

	override fun onInitialize() {
		Reflection.initialize(Attachments.javaClass)

		ServerPlayerEvents.JOIN.register { player ->
			val attachments = PlayerAttachments(player)
			if (attachments.hasJoined) return@register

			attachments.markJoined()
			val height = randomPlayerHeight()
			attachments.heightModifier = height
			val scale = player.getAttribute(Attributes.SCALE)
			if (scale != null && scale.getModifier(SIZE_MODIFIER) == null) {
				scale.addPermanentModifier(
					AttributeModifier(
						SIZE_MODIFIER,
						height - 1.0,
						AttributeModifier.Operation.ADD_VALUE
					)
				)
			}
		}

		ServerPlayerEvents.COPY_FROM.register { oldPlayer, newPlayer, _ ->
			val oldAttachments = PlayerAttachments(oldPlayer)
			val newAttachments = PlayerAttachments(newPlayer)

			val height = oldAttachments.heightModifier
			newAttachments.heightModifier = height

			val scale = newPlayer.getAttribute(Attributes.SCALE)

			scale?.addPermanentModifier(
				AttributeModifier(
					SIZE_MODIFIER,
					height - 1.0,
					AttributeModifier.Operation.ADD_VALUE
				)
			)
		}

		CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
			dispatcher.register(
				Commands.literal("rerollheight")
					.requires(Commands.hasPermission(Commands.LEVEL_ADMINS))
					.then(
						Commands.argument("targets", EntityArgument.players())
							.executes { ctx ->
								val targets = EntityArgument.getPlayers(ctx, "targets")
								for (player in targets) {
									val height = randomPlayerHeight()
									applyHeight(player, height)
									ctx.source.sendSuccess(
										{
											Component.literal(
												"Rerolled ${player.gameProfile.name}'s height to " +
														"%.2f m".format(height * 1.88)
											)
										},
										true
									)
								}
								targets.size
							}
					)
			)
		}
	}

	fun id(path: String): Identifier
		= Identifier.fromNamespaceAndPath(MOD_ID, path)

	fun randomPlayerHeight(): Double {
		val meanHeight = 1.88
		val standardDeviation = 0.08

		val height = meanHeight + Random.nextGaussian() * standardDeviation

		return height / meanHeight
	}

	fun applyHeight(player: ServerPlayer, height: Double) {
		PlayerAttachments(player).heightModifier = height

		val scale = player.getAttribute(Attributes.SCALE) ?: return
		scale.removeModifier(SIZE_MODIFIER)
		scale.addPermanentModifier(
			AttributeModifier(
				SIZE_MODIFIER,
				height - 1.0,
				AttributeModifier.Operation.ADD_VALUE
			)
		)
	}

	fun Random.nextGaussian(): Double {
		val u1 = nextDouble().coerceAtLeast(Double.MIN_VALUE)
		val u2 = nextDouble()

		return kotlin.math.sqrt(-2.0 * kotlin.math.ln(u1)) *
				kotlin.math.cos(2.0 * Math.PI * u2)
	}
}
